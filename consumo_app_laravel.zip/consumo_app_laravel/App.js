import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Text, View } from 'react-native';

export default App = () => {
  const [data, setData] = useState([]);

  const getEditoriales = async () => {
     try {
      const response = await fetch('http://localhost/demo_laravel/public/api/editoriales');
      const json = await response.json();
      console.log(json);
      setData(json);
    } catch (error) {
      console.error(error);
    } 
  }

  useEffect(() => {
    getEditoriales();
  }, []);

  return (
    <View style={{ flex: 1, padding: 24 }}>
     <FlatList
          data={data}
          keyExtractor={({ id }, index) => id}
          renderItem={({ item }) => (
            <Text>{item.codigo_editorial}, {item.nombre_editorial}<br/>{item.contacto}, {item.telefono}<br/> </Text>
          )}
        />
    </View>
  );
};